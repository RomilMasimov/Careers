﻿namespace Careers.Models
{
    public class ImagePath
    {
        public int Id { get; set; }
        public string Path { get; set; }
    }
}