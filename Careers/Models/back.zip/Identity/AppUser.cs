﻿using Microsoft.AspNetCore.Identity;

namespace Careers.Models.Identity
{
    public class AppUser : IdentityUser
    {
       
    }
}
