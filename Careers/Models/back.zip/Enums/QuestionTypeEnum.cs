﻿namespace Careers.Models.Enums
{
    public enum QuestionTypeEnum
    {
        Single,
        Multi
    }
}
