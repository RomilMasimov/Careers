﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Careers.Models.Enums
{
    public enum MeetingPointTypeEnum
    {
        District = 0,
        City = 1,
        Subway = 2,
    }
}
