﻿namespace Careers.Models.Enums
{
    public enum ImageOwnerEnum
    {
        Client,
        Specialist
    }
}
