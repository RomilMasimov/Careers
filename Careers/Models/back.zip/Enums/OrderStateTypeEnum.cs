﻿namespace Careers.Models.Enums
{
    public enum OrderStateTypeEnum
    {

    }
}