﻿namespace Careers.Models
{
    public class ServiceReview
    {
        public int  Id { get; set; }
        public Review Review { get; set; }
        public int ReviewId { get; set; }
        public Service Service { get; set; }
        public int ServiceId { get; set; }
    }
}